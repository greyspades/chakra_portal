"use strict";
(() => {
var exports = {};
exports.id = 607;
exports.ids = [607];
exports.modules = {

/***/ 4903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
async function handler(req, res) {
    const options = {
        method: req.body.method,
        headers: {
            "Content-Type": "application/json",
            Auth: req.body.head
        },
        body: req.body.body
    };
    // console.log(req.body.body)
    // console.log(req.body)
    let response = await fetch(req.body.url, options).then((res)=>{
        let resData = res.json();
        return resData;
    }).catch((err)=>{
        console.log(err);
    });
    res.status(200).json(response);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4903));
module.exports = __webpack_exports__;

})();