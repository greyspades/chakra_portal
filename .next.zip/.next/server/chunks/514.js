exports.id = 514;
exports.ids = [514];
exports.modules = {

/***/ 8931:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ Application)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1939);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9226);
/* harmony import */ var _mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6872);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3199);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_CalendarToday__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6796);
/* harmony import */ var _mui_icons_material_CalendarToday__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CalendarToday__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_Business__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6283);
/* harmony import */ var _mui_icons_material_Business__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Business__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_WorkOutline__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3508);
/* harmony import */ var _mui_icons_material_WorkOutline__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_WorkOutline__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6146);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_Book__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1680);
/* harmony import */ var _mui_icons_material_Book__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Book__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _helpers_validation__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(483);
/* harmony import */ var _notifier__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3993);
/* harmony import */ var _mui_icons_material_Article__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(637);
/* harmony import */ var _mui_icons_material_Article__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Article__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _customInput__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(2598);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(5666);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _helpers_formating__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(232);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];























const Application = ({ name , id  })=>{
    const [info, setInfo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [file, setFile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [expForm, setExpForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [skillForm, setSkillForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [eduField, setEdufield] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [gender, setGender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Male");
    const [fileError, setFileError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [genError, setGenError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // const [hasCert, setHasCert] = useState<boolean>();
    const [basicInfo, setBasicInfo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [gradError, setGradErr] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        open: false
    });
    var key = crypto_js__WEBPACK_IMPORTED_MODULE_21___default().enc.Utf8.parse("yy7a1^.^^j_ii^c2^5^ho_@.9^d7bi^.");
    var iv = crypto_js__WEBPACK_IMPORTED_MODULE_21___default().enc.Utf8.parse("h!!_2bz^(@?yyq!.");
    //* context hook holding global state
    const { setCandidate , setRole  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context__WEBPACK_IMPORTED_MODULE_8__/* .MainContext */ .T);
    //* router hook for routing operations
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    //* genders for gender selection
    const genders = [
        "Male",
        "Female"
    ];
    //* gets basic user info from session storage
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const bytes = crypto_js__WEBPACK_IMPORTED_MODULE_21___default().AES.decrypt(sessionStorage.getItem("cred") ?? "", "yy7a1^.^^j_ii^c2^5^ho_@.9^d7bi^.");
        const data = JSON.parse(bytes.toString((crypto_js__WEBPACK_IMPORTED_MODULE_21___default().enc.Utf8)));
        const mainData = (0,_helpers_formating__WEBPACK_IMPORTED_MODULE_22__/* .lowerKey */ .w)(data);
        if (data) {
            // console.log(data)
            setBasicInfo(mainData);
            setGender(mainData?.gender);
        }
    }, []);
    //* qualifications for qualification selection
    const degrees = [
        "BSC",
        "MSC",
        "MBA",
        "PHD",
        "HND",
        "OND",
        "Other"
    ];
    //* handles resume selection
    const handleFileChange = (e)=>{
        let extensions = [
            "pdf"
        ];
        let file = e.target.files[0];
        let type = file.name.split(".");
        //* if the file is pdf and less than 3mb
        if (extensions.includes(type[type.length - 1]) && file.size < 2000000) {
            setFile(e.target.files[0]);
            setFileError("");
        } else if (!extensions.includes(type[type.length - 1])) {
            setFileError("please select a pdf");
        } else if (!(file.size < 3000000)) {
            setFileError("please select a file less than 3mb");
        }
    };
    //* handles changes to the experience fields
    const handleExpChange = (type, index, e)=>{
        //* if the candidate currently works at the organization
        if (type != "isCurrent") {
            var update = expForm?.map((item, idx)=>{
                if (idx == index) {
                    item[type] = e.target.value;
                }
                return item;
            });
            setExpForm(update);
        } else {
            //* update the field based on its index in the array
            var update = expForm?.map((item, idx)=>{
                if (idx == index) {
                    item.isCurrent = !item.isCurrent;
                }
                return item;
            });
            setExpForm(update);
        }
    };
    //* removes the current experience field
    const removeExp = (id)=>{
        const update = expForm?.filter((item)=>expForm.indexOf(item) != id);
        setExpForm(update);
    };
    //* removes the current education field
    const removeEdu = (id)=>{
        const update = eduField?.filter((item)=>eduField.indexOf(item) != id);
        setEdufield(update);
    };
    //* renders the experience forms
    const renderExperience = ()=>{
        return expForm?.map((item, idx)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "grid md:px-4 mt-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid justify-end mb-[20px]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                            className: "bg-green-300 h-[35px] w-[35px]",
                            onClick: ()=>removeExp(idx),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16___default()), {
                                className: "w-[15px] h-[15px]"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex md:flex-row flex-col md:gap-2 gap-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                value: item.employer,
                                onChange: (e)=>handleExpChange("employer", idx, e),
                                component: "text",
                                placeHolder: "Employer",
                                classes: "h-[40px] md:w-[100%] w-[100%] bg-gray-100 rounded-md no-underline px-1 shadow-md",
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Business__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    className: "text-green-700"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                value: item.title,
                                onChange: (e)=>handleExpChange("title", idx, e),
                                component: "text",
                                placeHolder: "Title",
                                classes: "h-[40px] md:w-[95%] w-[100%] bg-gray-100 rounded-md no-underline px-1 shadow-md",
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_WorkOutline__WEBPACK_IMPORTED_MODULE_12___default()), {
                                    className: "text-green-700"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row md:gap-2 gap-2 md:mt-0 mt-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                        value: item.startDate,
                                        onChange: (e)=>handleExpChange("startDate", idx, e),
                                        component: "text",
                                        placeHolder: "Start Date",
                                        type: "date",
                                        classes: "h-[40px] md:w-[95%] w-[140px] bg-gray-100 rounded-md no-underline px-1 shadow-md"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                        disabled: item?.isCurrent ? true : false,
                                        value: item.endDate,
                                        onChange: (e)=>handleExpChange("endDate", idx, e),
                                        component: "text",
                                        type: "date",
                                        placeHolder: "End Date",
                                        classes: "h-[40px] md:w-[100%] w-[140px] bg-gray-100 rounded-md no-underline px-1 shadow-md"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                        className: "flex flex-col md:ml-4",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-[11px] mt-[-10px]",
                                                children: "Current"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Radio, {
                                                name: "isCurrent",
                                                className: "text-green-700",
                                                checked: item?.isCurrent === true,
                                                value: item?.isCurrent,
                                                onClick: (e)=>handleExpChange("isCurrent", idx, e)
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                            value: item.description,
                            onChange: (e)=>handleExpChange("description", idx, e),
                            component: "field",
                            type: "text",
                            placeHolder: "Description",
                            classes: "w-[100%] bg-gray-100 rounded-md no-underline shadow-md mt-[7px]",
                            rows: 4
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-[30px] text-[11px]",
                        children: item?.hasError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-red-600",
                            children: "Please fill out the information"
                        })
                    })
                ]
            }, idx);
        });
    };
    //* add new education form
    const addEdu = (type, e, index)=>{
        //* if the candidate has other qualifications
        if (type == "degree" && e.target.value == "Other") {
            let update = eduField?.map((item, idx)=>{
                if (idx == index) {
                    item.hasCert = true;
                }
                return item;
            });
            setEdufield(update);
        }
        if (type == "graduationDate") {
            //* if the field type is is graduation date its validates its a past date
            var isPast = new Date(e.target.value) < new Date(new Date());
            if (isPast) {
                let update1 = eduField?.map((item, idx)=>{
                    if (idx == index) {
                        item[type] = e.target.value;
                    }
                    return item;
                });
                setEdufield(update1);
                setGradErr(false);
            } else {
                setGradErr(true);
            }
        } else {
            let update2 = eduField?.map((item, idx)=>{
                if (idx == index) {
                    item[type] = e.target.value;
                }
                return item;
            });
            setEdufield(update2);
        }
    };
    //* removes other certifications
    const removeCert = (index)=>{
        let update = eduField?.map((item, idx)=>{
            if (idx == index) {
                item.hasCert = false;
                item.certification = "";
            }
            return item;
        });
        setEdufield(update);
    };
    //* renders the education fields
    const renderEducation = ()=>{
        return eduField.map((item, idx)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid justify-end",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                            className: "bg-green-300 h-[35px] w-[35px]",
                            onClick: ()=>removeEdu(idx),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16___default()), {
                                className: "w-[15px] h-[15px]"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid md:grid-cols-2 mt-[-10px]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                value: item.school,
                                onChange: (e)=>addEdu("school", e, idx),
                                component: "text",
                                placeHolder: "School Attended",
                                classes: "h-[40px] md:w-[350px] w-[100%] bg-gray-100 rounded-md no-underline px-2 shadow-md mb-4",
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Book__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    className: "text-green-700"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                value: item.course,
                                onChange: (e)=>addEdu("course", e, idx),
                                component: "text",
                                placeHolder: "Course of study",
                                classes: "h-[40px] md:w-[350px] w-[100%] bg-gray-100 rounded-md no-underline px-2 shadow-md mb-4",
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Book__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    className: "text-green-700"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row gap-2 md:mt-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                        value: item.graduationDate,
                                        onChange: (e)=>addEdu("graduationDate", e, idx),
                                        component: "text",
                                        type: "date",
                                        placeHolder: "Graduation date",
                                        classes: "h-[40px] md:w-[180px] w-[170px] bg-gray-100 rounded-md no-underline px-2 shadow-md mb-4",
                                        // icon={<CalendarTodayIcon className="text-green-700" />}
                                        error: gradError ? "Please select a past date" : null
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                        value: item.degree,
                                        onChange: (e)=>addEdu("degree", e, idx),
                                        component: "select",
                                        selValues: degrees,
                                        placeHolder: "Qualification",
                                        classes: "h-[40px] w-[150px] bg-gray-100 rounded-md no-underline px-2 shadow-md mt-4",
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CalendarToday__WEBPACK_IMPORTED_MODULE_10___default()), {
                                            className: "text-green-700"
                                        })
                                    })
                                ]
                            }),
                            item?.hasCert && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mt-[15px] flex flex-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                        value: item.certification,
                                        onChange: (e)=>addEdu("certification", e, idx),
                                        component: "text",
                                        placeHolder: "Certification",
                                        classes: "h-[40px] md:w-[350px] w-[280px] bg-gray-100 rounded-md no-underline px-2 shadow-md mb-4",
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Article__WEBPACK_IMPORTED_MODULE_19___default()), {
                                            className: "text-green-700"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                        className: "bg-green-300 h-[25px] w-[25px]",
                                        onClick: ()=>removeCert(idx),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16___default()), {
                                            className: "h-[15px] w-[15px]"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }, idx));
    };
    //* adds a new experience form
    const addExpField = ()=>{
        var newField = {
            employer: "",
            title: "",
            startDate: "",
            endDate: "",
            isCurrent: false,
            hasError: false
        };
        var update = [
            ...expForm,
            newField
        ];
        setExpForm(update);
    };
    //* adds a new education form
    const addEduField = ()=>{
        let newField = {
            school: "",
            course: "",
            graduationDate: "",
            degree: "BSC",
            certification: "",
            hasCert: false
        };
        var update = [
            ...eduField,
            newField
        ];
        setEdufield(update);
    };
    //* adds a new skill form
    const addSkillField = ()=>{
        if (skillForm[skillForm.length - 1] != "") {
            let newSkill = "";
            var update = [
                ...skillForm,
                newSkill
            ];
            setSkillForm(update);
        }
    };
    //* inputs a new skill into the indexed form
    const addKill = (e, index)=>{
        let update = skillForm?.map((item, idx)=>{
            if (idx == index) {
                item = e.target.value;
            }
            return item;
        });
        setSkillForm(update);
    };
    //* removes the indexed skill field
    const removeSkill = (index)=>{
        const update = skillForm?.filter((item)=>skillForm.indexOf(item) != index);
        setSkillForm(update);
    };
    //* renders the skill forms
    const renderSkills = ()=>{
        return skillForm?.map((item, idx)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row align-middle",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                        value: item,
                        onChange: (e)=>addKill(e, idx),
                        component: "text",
                        placeHolder: "Skill",
                        classes: "md:w-[200px] w-[160px] h-[40px] bg-gray-100 rounded-md no-underline shadow-md mb-4 px-2"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                        className: "mt-[-11px] ml-[-7px] mr-[35px] bg-green-300 h-[10px] w-[10px]",
                        onClick: ()=>removeSkill(idx),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16___default()), {
                            className: "w-[13px] h-[13px]"
                        })
                    })
                ]
            }, idx));
    };
    //* clears the notifier state
    const clearStatus = ()=>setStatus({
            open: false
        });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Modal, {
                className: "flex justify-center",
                open: status?.open ? true : false,
                onClose: clearStatus,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_notifier__WEBPACK_IMPORTED_MODULE_18__/* .Notifier */ .d, {
                    topic: status?.topic ?? "",
                    content: status?.content ?? "",
                    close: clearStatus
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Paper, {
                className: "flex flex-col justify-items-center md:h-[90vh] bg-white overflow-y-scroll pb-[100px] m-2 md:px-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-center font-bold text-xl mt-4 mb-[40px]",
                        children: "Personal Information"
                    }),
                    basicInfo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_3__.Formik, {
                            validationSchema: _helpers_validation__WEBPACK_IMPORTED_MODULE_17__/* .ApplicationValidation */ .NT,
                            initialValues: {
                                firstName: basicInfo.firstname,
                                lastName: basicInfo.lastname,
                                otherName: basicInfo.othername,
                                email: basicInfo?.email,
                                phone: basicInfo?.phone,
                                school: "",
                                degree: "",
                                field: "",
                                dob: basicInfo?.dob.split("T")[0],
                                gender: basicInfo?.gender,
                                password: "",
                                coverLetter: ""
                            },
                            //* called once the submit button is clicked
                            onSubmit: async (value, { validateForm  })=>{
                                //* validates the form against the schema
                                validateForm(value);
                                //* request body
                                var body = {
                                    firstName: value.firstName,
                                    lastName: value.lastName,
                                    otherName: value.otherName,
                                    email: value.email,
                                    phone: value.phone.toString(),
                                    education: JSON.stringify(eduField),
                                    experience: JSON.stringify(expForm),
                                    skills: skillForm,
                                    dob: value.dob.toString(),
                                    roleId: id,
                                    gender: gender,
                                    password: value.password,
                                    jobName: name,
                                    coverLetter: value.coverLetter,
                                    cv: file
                                };
                                //* candidate object
                                const candidateObj = {
                                    firstname: value.firstname,
                                    lastname: value.lastname,
                                    email: value.email,
                                    phone: value.phone.toString(),
                                    dob: value.dob.toString(),
                                    roleid: id
                                };
                                //* payload for updating the role
                                const roleObj = {
                                    name: name
                                };
                                //* checks the file type
                                let typeArr = file?.name.split(".");
                                let type = typeArr?.[typeArr?.length - 1];
                                expForm.forEach((item, idx)=>{
                                    if (!item.title || !item.startDate || !item.employer) {
                                        let update = expForm.map((exp, index)=>{
                                            if (idx == index) {
                                                exp.hasError = true;
                                            }
                                            return exp;
                                        });
                                        setExpForm(update);
                                        setGenError(true);
                                    }
                                });
                                eduField.forEach((item, idx)=>{
                                    if (!item.course || !item.graduationDate || !item.degree || !item.school) {
                                        let update = eduField.map((edu, index)=>{
                                            if (idx == index) {
                                                edu.hasError = true;
                                            }
                                            return edu;
                                        });
                                        setEdufield(update);
                                        setGenError(true);
                                    }
                                });
                                let expResult = expForm.every((item)=>item.title != "" && item.startDate != "" && item.employer != "");
                                let eduResult = eduField.every((item)=>item.course != "" && item.graduationDate != "" && item.degree != "" && item.school != "");
                                if (type == "pdf" && expResult && eduResult && expForm.length > 0 && eduField.length > 0) {
                                    setGenError(false);
                                    setLoading(true);
                                    let reqHeader = crypto_js__WEBPACK_IMPORTED_MODULE_21___default().AES.encrypt("68a4b2bfc07444b7822c3e8a14cbac6d732311b8c9344096a32ea51c568193c7", key, {
                                        iv: iv
                                    }).toString();
                                    const options = {
                                        head: reqHeader,
                                        body: body,
                                        url: "http://10.0.0.153:8443/api/Candidate/create"
                                    };
                                    axios__WEBPACK_IMPORTED_MODULE_2__["default"].post("/api/create", options, {
                                        headers: {
                                            "Content-Type": "application/json",
                                            "Auth": reqHeader
                                        }
                                    }).then((res)=>{
                                        setLoading(false);
                                        if (res.data.code == 200) {
                                            setCandidate(candidateObj);
                                            setRole(roleObj);
                                            router.push("/confirmation");
                                        } else {
                                            setStatus({
                                                open: true,
                                                topic: "Unsuccessful",
                                                content: res.data.message
                                            });
                                        }
                                    }).catch((err)=>{
                                        console.log(err.message);
                                        setLoading(false);
                                        setStatus({
                                            open: true,
                                            topic: "Unsuccessful",
                                            content: err.message
                                        });
                                    });
                                } else if (type != "pdf") {
                                    setFileError("Please Select a pdf file for your resume");
                                } else if (!eduResult || !expResult) {
                                    setStatus({
                                        open: true,
                                        topic: "Unsuccessful",
                                        content: "Please fill in the missing fields in your application"
                                    });
                                } else if (expForm.length < 1) {
                                    setStatus({
                                        open: true,
                                        topic: "Unsuccessful",
                                        content: "Please add some work experience to your application"
                                    });
                                } else if (eduField.length < 1) {
                                    setStatus({
                                        open: true,
                                        topic: "Unsuccessful",
                                        content: "Please add some education to your application"
                                    });
                                }
                            },
                            children: ({ handleSubmit , handleChange , values , errors  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid justify-items-center",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex md:flex-row flex-col gap-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    value: values.firstName,
                                                    onChange: handleChange("firstName"),
                                                    component: "text",
                                                    placeHolder: "First Name",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                        className: "text-green-700"
                                                    }),
                                                    error: errors.firstName
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    value: values.otherName,
                                                    onChange: handleChange("otherName"),
                                                    component: "text",
                                                    placeHolder: "Other Name",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                        className: "text-green-700"
                                                    }),
                                                    error: errors.otherName
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    value: values.lastName,
                                                    onChange: handleChange("lastName"),
                                                    component: "text",
                                                    placeHolder: "Last Name",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                        className: "text-green-700"
                                                    }),
                                                    error: errors.lastName
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex md:flex-row flex-col gap-6 mt-[30px]",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    value: values.email,
                                                    onChange: handleChange("email"),
                                                    component: "text",
                                                    placeHolder: "Email",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        className: "text-green-700"
                                                    }),
                                                    error: errors.email
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    value: values.phone,
                                                    onChange: handleChange("phone"),
                                                    component: "text",
                                                    placeHolder: "Phone number",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        className: "text-green-700"
                                                    }),
                                                    error: errors.phone
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex md:flex-row flex-col gap-2 mt-[30px]",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    value: values.dob,
                                                    onChange: handleChange("dob"),
                                                    component: "text",
                                                    type: "date",
                                                    placeHolder: "Date of Birth",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CalendarToday__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                        className: "text-green-700"
                                                    }),
                                                    error: errors.dob
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    value: values.gender,
                                                    onChange: handleChange("otherName"),
                                                    component: "select",
                                                    placeHolder: "Gender",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md mt-[15px]",
                                                    selValues: genders,
                                                    error: errors.gender
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                    onChange: handleFileChange,
                                                    component: "text",
                                                    helper: "Pdf only",
                                                    type: "file",
                                                    placeHolder: "Resume",
                                                    readonly: true,
                                                    classes: "h-[40px] md:w-[100%] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                    selValues: genders,
                                                    error: fileError
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-[98%] my-[20px]",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_20__/* .CustomInput */ .t, {
                                                value: values.coverLetter,
                                                onChange: handleChange("coverLetter"),
                                                component: "field",
                                                type: "text",
                                                placeHolder: "Cover letter",
                                                rows: 4,
                                                classes: " bg-gray-100 w-[100%] rounded-md no-underline shadow-md mt-4",
                                                error: errors?.coverLetter
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-[100%]",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                    className: "bg-green-700 h-[2px] md:mx-6 mx-2"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "font-bold pl-7 mt-2",
                                                    children: "Work Experience"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "p-4",
                                                    children: renderExperience()
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                    onClick: addExpField,
                                                    className: "flex flex-row text-green-700 align-middle pl-6 capitalize",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Add Work Experience"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_14___default()), {})
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-[100%]",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                    className: "bg-green-700 h-[2px] md:mx-6 mx-2"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "mb-6 font-bold pl-7 mt-4",
                                                    children: "Skills"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "grid md:grid-cols-4 grid-cols-2 md:px-6 px-2 md:gap-12 gap-2",
                                                    children: renderSkills()
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                    onClick: addSkillField,
                                                    className: "flex flex-row text-green-700 align-middle pl-6 capitalize",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Add Skill"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_14___default()), {})
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-[100%]",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                    className: "bg-green-700 h-[2px] md:mx-6 mx-2"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "font-bold pl-7 mt-4 mb-6",
                                                    children: "Education/Certifications"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "md:mx-6 mx-2",
                                                    children: renderEducation()
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                    onClick: addEduField,
                                                    className: "flex flex-row text-green-700 align-middle pl-6 capitalize",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Add Qualification"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_14___default()), {})
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "md:mt-[30px] mt-[50px]",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                className: "bg-green-700 text-white w-[150px]",
                                                onClick: ()=>handleSubmit(),
                                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.CircularProgress, {
                                                    thickness: 7,
                                                    className: "text-white w-[40px] h-[40px] p-1"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Submit"
                                                })
                                            })
                                        }),
                                        genError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "p-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-red-600 text-[11px]",
                                                children: "Please fill out the missing fields"
                                            })
                                        })
                                    ]
                                })
                        })
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ JobFilters)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2625);
/* harmony import */ var _mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _customInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2598);






const JobFilters = ({ fields , change , searchVal , searchRole , checkFields , jobTypeChange , jobType , eduType , eduTypeChange , mobile , hideFilter  })=>{
    const jobTypes = [
        "Full time",
        "Part time",
        "Contract",
        "Internship"
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>console.log(mobile), []);
    const degrees = [
        "BSC",
        "MSC",
        "MBA",
        "PHD",
        "HND",
        "OND",
        "Other"
    ];
    const filterFields = [
        {
            title: "Locations",
            field: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_5__/* .CustomInput */ .t, {
                value: fields.location,
                onChange: (e)=>change(e, "location"),
                component: "text",
                placeHolder: "Lagos, Benin, Abuja",
                classes: "h-[50px] w-[100%] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_4___default()), {})
            })
        },
        // {
        //   title: "Skill",
        //   field: (
        //     <Input
        //       value={fields.skill}
        //       onChange={(e) => change(e, "skill")}
        //       className="h-[50px] w-[100%] bg-white border-green-700 border-solid border-2 rounded-md no-underline px-4 shadow-lg"
        //       placeholder="Communications, Teamwork, Leadership"
        //       disableUnderline
        //     />
        //   ),
        // },
        {
            title: "Degree",
            field: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_5__/* .CustomInput */ .t, {
                value: eduType,
                onChange: eduTypeChange,
                component: "select",
                selValues: degrees,
                classes: "h-[50px] w-[100%] bg-gray-100 rounded-md no-underline px-4 shadow-md"
            })
        },
        {
            title: "Job types",
            field: // <Select
            //   value={jobType}
            //   onChange={jobTypeChange}
            //   className="h-[50px] w-[100%] bg-gray-200 border-green-700 border-solid border-2 rounded-md no-underline px-4 shadow-lg"
            //   >{jobTypes.map((item: string, idx: number) => (
            //     <MenuItem key={idx} value={item}>
            //       {item}
            //     </MenuItem>
            //   ))}</Select>
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_5__/* .CustomInput */ .t, {
                value: jobType,
                onChange: jobTypeChange,
                component: "select",
                selValues: jobTypes,
                classes: "h-[50px] w-[100%] bg-gray-100 rounded-md no-underline px-4 shadow-md"
            })
        }
    ];
    const renderFields = ()=>{
        return filterFields.map((item, idx)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Accordion, {
                className: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.AccordionSummary, {
                        className: "h-[70px]",
                        expandIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.ExpandMore, {}),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            className: "font-semibold text-[16px]",
                            children: item.title
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.AccordionDetails, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: item.field
                        })
                    })
                ]
            }, idx));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "h-auto",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col md:flex-row md:justify-center justify-between bg-white p-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_5__/* .CustomInput */ .t, {
                        value: searchVal,
                        onChange: (e)=>searchRole(e),
                        component: "text",
                        placeHolder: "Search for a job role",
                        classes: "h-[50px] w-[100%] bg-gray-100 rounded-md no-underline px-4 shadow-md"
                    }),
                    mobile && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            className: "",
                            onClick: hideFilter,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-green-700 text-[12px]",
                                children: "Hide filters"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "overflow-y-scroll",
                children: renderFields()
            })
        ]
    });
};


/***/ }),

/***/ 6497:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ JobList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2625);
/* harmony import */ var _mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Badge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9740);
/* harmony import */ var _mui_icons_material_Badge__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Badge__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Refresh__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6527);
/* harmony import */ var _mui_icons_material_Refresh__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Refresh__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7834);
/* harmony import */ var _mui_icons_material_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(547);
/* harmony import */ var _mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_7__);








const JobList = ({ roles , setRole , apply , getRoles , currentStep , refresh , count  })=>{
    const [page, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const nextPage = ()=>{
        if (roles.length > 0) {
            setPage((page)=>page + 1);
            getRoles(page + 1);
            window.scrollTo(0, 0);
        }
    };
    const prevPage = ()=>{
        if (page > 0) {
            setPage((page)=>page - 1);
            getRoles(page - 1);
            window.scrollTo(0, 0);
        }
    };
    const goToLast = ()=>{
        let lastPage = parseInt((count / 10).toString(), 10) - 1;
        console.log(lastPage);
        setPage(lastPage);
        getRoles(1);
        window.scrollTo(0, 0);
    };
    const goToFirst = ()=>{
        setPage(0);
        getRoles(0);
        window.scrollTo(0, 0);
    };
    //* parses and maps through the job descriptions
    const parseDesc = (desc)=>{
        if (desc) {
            return JSON.parse(desc).map((item, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row gap-4 mt-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: item?.["RowNum~~Blnk"]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "capitalize",
                                children: item?.["Job responsibility~~Sentc"]?.toLowerCase()
                            })
                        ]
                    })
                }, idx));
        } else {
            return "";
        }
    };
    const parseSkills = (skills)=>{
        if (skills) {
            return JSON.parse(skills).map((item, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-black border-2 border-green-700 border-solid rounded-lg px-2 py-1",
                    children: item
                }, idx));
        }
    };
    const toggleExpansion = (index)=>{
        let update = roles.map((item, idx)=>{
            if (index == idx) {
                item.expanded = !item.expanded;
            }
            return item;
        });
        setRole(update);
    };
    const renderRoles = ()=>{
        return roles?.map((item, idx)=>{
            // if(item.status == "active") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mb-8",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Paper, {
                    className: currentStep == 1 ? "bg-white p-2 md:px-8 px-2" : "bg-white p-2 md:px-4 px-2",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "my-2 md:px-0 px-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-semibold md:text-[24px] text-[20px]",
                                        children: item?.name
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-[100%] justify-between flex flex-row md:px-0 px-2",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: currentStep == 1 ? "md:w-[50%] w-[100%] flex flex-row gap-8" : "w-[150%] flex flex-row gap-2",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-row place-items-center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        className: "text-green-700 w-[17px] h-[17px]"
                                                    }),
                                                    item?.location ?? "maryland bus stop"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-row place-items-center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Badge__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        className: "text-green-700 w-[17px] h-[17px]"
                                                    }),
                                                    item?.jobtype ?? "Full time"
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {
                            variant: "middle",
                            className: "mx-0 my-4"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mx-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-semibold text-[20px]",
                                        children: "Job description:"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: !item.expanded ? "h-[10px] overflow-hidden" : "",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: parseDesc(item.description)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mt-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "font-semibold text-[20px]",
                                                children: "Required Skills:"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex flex-row gap-4 mt-2 flex-wrap",
                                            children: parseSkills(item.skills)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mt-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "font-semibold text-[20px]",
                                                children: "Qualifications:"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex flex-row gap-4 mt-2",
                                            children: item?.qualification
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex justify-center mt-6",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                className: "bg-green-700 h-[40px] md:w-[30%] w-[90%] capitalize text-white",
                                                onClick: ()=>apply(item),
                                                children: "Apply"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex justify-center mt-6",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                onClick: ()=>toggleExpansion(idx),
                                className: "text-green-700",
                                children: item.expanded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Show less"
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "Show more"
                                })
                            })
                        })
                    ]
                })
            }, idx);
        // }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "text-[14px] md:text-[16px]",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "",
                children: renderRoles()
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-center bg-white h-[60px] rounded-md flex-row",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: currentStep == 1 ? "flex flex-row md:w-[50%] w-[80%] justify-between place-items-center" : "flex flex-row w-[100%] justify-between place-items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-row justify-center place-items-center gap-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                    className: "rounded-full shadow-md",
                                    onClick: prevPage,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowLeft__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        className: "text-green-700 w-[30px] h-[30px]"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row place-items-center gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "semibold",
                                        children: "Page"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-[18px] text-green-700 font-semibold",
                                        children: page + 1
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-row justify-center place-items-center gap-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                    className: "rounded-full shadow-md",
                                    onClick: nextPage,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowRight__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        className: "text-green-700 w-[30px] h-[30px]"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex place-items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                            className: "ml-[30px] rounded-full shadow-md",
                            onClick: refresh,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Refresh__WEBPACK_IMPORTED_MODULE_5___default()), {
                                className: "text-green-700"
                            })
                        })
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 5069:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ Signup)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1939);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9226);
/* harmony import */ var _mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(773);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7749);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3199);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _helpers_validation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(483);
/* harmony import */ var _notifier__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3993);
/* harmony import */ var react_phone_input_2__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5452);
/* harmony import */ var react_phone_input_2__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_phone_input_2__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_phone_input_2_lib_style_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4463);
/* harmony import */ var react_phone_input_2_lib_style_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_phone_input_2_lib_style_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var naija_state_local_government__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7435);
/* harmony import */ var naija_state_local_government__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(naija_state_local_government__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _customInput__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2598);
/* harmony import */ var _mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3467);
/* harmony import */ var _mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5666);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _helpers_connection__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1423);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_helpers_connection__WEBPACK_IMPORTED_MODULE_20__]);
_helpers_connection__WEBPACK_IMPORTED_MODULE_20__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





















const Signup = ({ exit , next , login , isStatus , nextPage  })=>{
    const [info, setInfo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [signInLoad, setsignInLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [signupLoad, setSignupLoad] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [visible, setVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [gender, setGender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Male");
    const [maritalStatus, setMaritalStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Single");
    const [isLogin, setIsLogin] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(login);
    const [phone, setPhone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [reset, setReset] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        open: false
    });
    const [location, setLocation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        state: "Lagos",
        lga: "Ikeja"
    });
    const genders = [
        "Male",
        "Female"
    ];
    const maritalStatuses = [
        "Single",
        "Married",
        "Divorced"
    ];
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { setCandidates , loggedIn , setLoggedIn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context__WEBPACK_IMPORTED_MODULE_8__/* .MainContext */ .T);
    const clearStatus = ()=>setStatus({
            open: false
        });
    //* handles the next action for the notifier
    const handleNext = ()=>{
        setStatus({
            open: false
        });
        if (status.topic == "Successful") {
            exit?.();
            next?.();
        }
        router.push(`/${nextPage}`);
    };
    // useEffect(() => {
    //   // console.log(NaijaStates.lgas("Oyo"))
    //   console.log(NaijaStates.states())
    //   setLocation({ ...location, location?.state:})
    // },[location.state])
    //* handles phone number update
    const handlePhoneChange = (e)=>{
        setPhone(e);
    };
    const handleLocationChange = (e, type)=>{
        let update = {
            ...location,
            [type]: e.target.value
        };
        setLocation(update);
    };
    //* renames the fct state to abuja
    var updatedLoc = naija_state_local_government__WEBPACK_IMPORTED_MODULE_15___default().states().map((item)=>{
        if (item == "Federal Capital Territory") {
            item = "Abuja";
        }
        return item;
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Modal, {
                className: "flex justify-center",
                open: status?.open ? true : false,
                onClose: clearStatus,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_notifier__WEBPACK_IMPORTED_MODULE_11__/* .Notifier */ .d, {
                    topic: status?.topic ?? "",
                    content: status?.content ?? "",
                    close: handleNext,
                    hasNext: status?.hasNext,
                    other: handleNext
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                className: !isLogin ? "flex flex-col md:w-[100%] w-[380px] m-0 justify-items-center md:h-[85%] h-[100%] bg-white overflow-y-scroll md:p-4 p-0 md:pb-0 pb-8" : "flex flex-col md:w-[400px] w-[380px] justify-items-center md:h-[450px] mt-[20px] bg-white overflow-y-scroll p-4",
                children: [
                    !isLogin && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-center md:mt-0 mt-4 md:mb-[30px] mb-6",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-xl font-semibold md:ml-0 ml-8",
                                        children: "Sign Up"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                        className: "ml-auto mr-4 md:mr-0",
                                        onClick: exit,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_14__.Close, {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                                    validateOnChange: true,
                                    validateOnBlur: false,
                                    validationSchema: _helpers_validation__WEBPACK_IMPORTED_MODULE_10__/* .CandidateValidation */ .uE,
                                    initialValues: {
                                        firstName: "",
                                        lastName: "",
                                        otherName: "",
                                        email: "",
                                        phone: "",
                                        dob: "",
                                        password: "",
                                        address: "",
                                        validPassword: ""
                                    },
                                    onSubmit: (value)=>{
                                        // validateForm(value);
                                        setSignupLoad(true);
                                        var body = {
                                            firstName: value.firstName,
                                            lastName: value.lastName,
                                            otherName: value.otherName,
                                            email: value.email,
                                            phone: phone.toString(),
                                            dob: value.dob.toString(),
                                            gender: gender,
                                            password: value.password,
                                            address: value.address,
                                            maritalStatus: maritalStatus,
                                            state: location.state,
                                            lga: location.lga
                                        };
                                        let { password , ...sessionBody } = body;
                                        let sessionData = JSON.stringify(sessionBody);
                                        let encrypted = crypto_js__WEBPACK_IMPORTED_MODULE_19___default().AES.encrypt(sessionData, "yy7a1^.^^j_ii^c2^5^ho_@.9^d7bi^.").toString();
                                        (0,_helpers_connection__WEBPACK_IMPORTED_MODULE_20__/* .postAsync */ .Am)("http://10.0.0.153:8443/api/Candidate/user", body).then((res)=>{
                                            setSignupLoad(false);
                                            if (res.code == 200) {
                                                sessionStorage.setItem("cred", encrypted);
                                                setLoggedIn(true);
                                                setStatus({
                                                    open: true,
                                                    topic: "Successful",
                                                    content: "Successfully Created a Profile, Please click the link sent to your email to continue",
                                                    hasNext: true
                                                });
                                            } else {
                                                setStatus({
                                                    open: true,
                                                    topic: "Unsuccessful",
                                                    content: res.message
                                                });
                                            }
                                        }).catch((err)=>{
                                            console.log(err.message);
                                            setSignupLoad(false);
                                        });
                                    },
                                    children: ({ handleSubmit , handleChange , values , errors  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "grid justify-items-center",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex md:flex-row flex-col gap-3",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.firstName,
                                                            onChange: handleChange("firstName"),
                                                            component: "text",
                                                            placeHolder: "First name",
                                                            classes: "h-[40px] md:w-[270px] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                            error: errors.firstName,
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                className: "text-green-700"
                                                            }),
                                                            fitWidth: true,
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.otherName,
                                                            onChange: handleChange("otherName"),
                                                            component: "text",
                                                            placeHolder: "Other name",
                                                            classes: "h-[40px] w-[320px] md:w-[300px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                            error: errors.otherName,
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                className: "text-green-700"
                                                            }),
                                                            fitWidth: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.lastName,
                                                            onChange: handleChange("lastName"),
                                                            component: "text",
                                                            placeHolder: "Last name",
                                                            classes: "h-[40px] w-[320px] md:w-[270px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                            error: errors.lastName,
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                className: "text-green-700"
                                                            }),
                                                            fitWidth: true,
                                                            required: true
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex md:flex-row flex-col mt-4 gap-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.email,
                                                            onChange: handleChange("email"),
                                                            component: "text",
                                                            placeHolder: "Email",
                                                            type: "email",
                                                            classes: "h-[40px] w-[320px] md:w-[300px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                            error: errors.email,
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                className: "text-green-700"
                                                            }),
                                                            fitWidth: true,
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormControl, {
                                                            className: "mt-[-5px]",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "w-[100%] flex flex-row mb-[5px]",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "mr-2 text-red-700 text-[14px] mt-[-5px]",
                                                                            children: "*"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "text-[11px]",
                                                                            children: "Phone Number"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_phone_input_2__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                                    inputClass: "h-[40px] w-[320px] md:w-[300px] bg-gray-100 rounded-md no-underline shadow-md",
                                                                    country: "ng",
                                                                    value: phone,
                                                                    onChange: (phone)=>handlePhoneChange(phone),
                                                                    enableSearch: true,
                                                                    containerStyle: {
                                                                        height: 40
                                                                    },
                                                                    inputStyle: {
                                                                        height: 40
                                                                    }
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.dob,
                                                            onChange: handleChange("dob"),
                                                            component: "text",
                                                            type: "date",
                                                            placeHolder: "Date of birth",
                                                            classes: "h-[40px] md:w-[200px] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                            error: errors.dob,
                                                            // icon={<CalendarTodayIcon className="text-green-700" />}
                                                            fitWidth: true,
                                                            required: true
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex md:flex-row flex-col gap-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: gender,
                                                            onChange: (e)=>setGender(e.target.value),
                                                            component: "select",
                                                            placeHolder: "Gender",
                                                            selValues: genders,
                                                            classes: "h-[40px] md:w-[150px] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md mt-4",
                                                            fitWidth: true,
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: maritalStatus,
                                                            onChange: (e)=>setMaritalStatus(e.target.value),
                                                            component: "select",
                                                            placeHolder: "Marital Status",
                                                            selValues: maritalStatuses,
                                                            classes: "h-[40px] md:w-[150px] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md mt-4",
                                                            fitWidth: true,
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.address,
                                                            onChange: handleChange("address"),
                                                            component: "text",
                                                            placeHolder: "Residential address",
                                                            classes: "h-[40px] w-[320px] md:w-[500px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                            fitWidth: true,
                                                            required: true,
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_17___default()), {
                                                                className: "text-green-700"
                                                            }),
                                                            error: errors.address
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex md:flex-row flex-col md:mt-[30px] mt-2 justify-start md:gap-4 gap-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: location.state,
                                                            onChange: (e)=>handleLocationChange(e, "state"),
                                                            component: "select",
                                                            selValues: updatedLoc,
                                                            placeHolder: "State",
                                                            classes: "h-[40px] w-[320px] md:w-[150px] bg-gray-100 rounded-md no-underline px-4 shadow-md mt-4",
                                                            fitWidth: true,
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: location.lga,
                                                            onChange: (e)=>handleLocationChange(e, "lga"),
                                                            component: "select",
                                                            selValues: naija_state_local_government__WEBPACK_IMPORTED_MODULE_15___default().lgas(location?.state)?.lgas,
                                                            placeHolder: "City",
                                                            classes: "h-[40px] w-[320px] md:w-[150px] bg-gray-100 rounded-md no-underline px-4 shadow-md mt-4",
                                                            fitWidth: true,
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.password,
                                                            onChange: handleChange("password"),
                                                            component: "text",
                                                            placeHolder: "Password",
                                                            type: visible ? "text" : "password",
                                                            classes: "h-[40px] w-[280px] md:w-[300px] bg-gray-100 rounded-md no-underline px-4 shadow-lg",
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                                                onClick: ()=>setVisible(!visible),
                                                                children: visible ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_7___default()), {})
                                                            }),
                                                            error: errors.password,
                                                            endAdornment: true,
                                                            fitWidth: true,
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                            value: values.validPassword,
                                                            onChange: handleChange("validPassword"),
                                                            component: "text",
                                                            placeHolder: "Confirm Password",
                                                            type: visible ? "text" : "password",
                                                            classes: "h-[40px] w-[280px] md:w-[300px] bg-gray-100 rounded-md no-underline px-4 shadow-lg",
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                                                onClick: ()=>setVisible(!visible),
                                                                children: visible ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_7___default()), {})
                                                            }),
                                                            error: errors.validPassword,
                                                            endAdornment: true,
                                                            fitWidth: true,
                                                            required: true
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    children: [
                                                        "Already Have an Account?",
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>setIsLogin(true),
                                                            className: "text-green-700 my-6",
                                                            children: "Sign In"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                    className: "bg-green-700 text-white md:w-[60%] w-[85%] h-[40px]",
                                                    onClick: ()=>handleSubmit(),
                                                    children: signupLoad ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.CircularProgress, {
                                                        thickness: 7,
                                                        className: "text-white w-[40px] h-[40px] p-1"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        children: "Submit"
                                                    })
                                                })
                                            ]
                                        })
                                })
                            })
                        ]
                    }),
                    isLogin && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-xl font-semibold",
                                        children: "Sign in"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                        className: "ml-auto",
                                        onClick: exit,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_14__.Close, {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                                    validationSchema: _helpers_validation__WEBPACK_IMPORTED_MODULE_10__/* .SignInValidation */ .Gx,
                                    initialValues: {
                                        email: "",
                                        password: ""
                                    },
                                    onSubmit: (value, { validateForm  })=>{
                                        validateForm(value);
                                        setsignInLoad(true);
                                        let body = {
                                            email: value.email,
                                            password: value.password
                                        };
                                        if (!isStatus) {
                                            // console.log(process.env.NEXT_PUBLIC_SIGN_USER_IN)
                                            // console.log("na eeem naaaa")
                                            (0,_helpers_connection__WEBPACK_IMPORTED_MODULE_20__/* .postAsync */ .Am)("http://10.0.0.153:8443/api/Candidate/signin", body).then((res)=>{
                                                if (res.code == 200) {
                                                    let encrypted = crypto_js__WEBPACK_IMPORTED_MODULE_19___default().AES.encrypt(JSON.stringify({
                                                        ...res.data,
                                                        password: null
                                                    }), "yy7a1^.^^j_ii^c2^5^ho_@.9^d7bi^.").toString();
                                                    sessionStorage.setItem("cred", encrypted);
                                                    setLoggedIn(true);
                                                    setStatus({
                                                        open: true,
                                                        topic: "Successful",
                                                        content: "Successfully Logged in"
                                                    });
                                                } else {
                                                    setStatus({
                                                        open: true,
                                                        topic: "Unsuccessful",
                                                        content: res.message
                                                    });
                                                }
                                            }).catch((err)=>{
                                                console.log(err.message);
                                                setStatus({
                                                    open: true,
                                                    topic: "Unsuccessful",
                                                    content: err.message
                                                });
                                            });
                                        } else {
                                            (0,_helpers_connection__WEBPACK_IMPORTED_MODULE_20__/* .postAsync */ .Am)("http://10.0.0.153:8443/status", body).then((res)=>{
                                                setsignInLoad(false);
                                                if (res.code == 200 && res.data.length > 0) {
                                                    setCandidates(res.data);
                                                    router.push("/applicant");
                                                } else if (res.code != 200) {
                                                    setStatus({
                                                        open: true,
                                                        topic: "Unsuccessful",
                                                        content: res.message
                                                    });
                                                }
                                            });
                                        }
                                    },
                                    children: ({ handleSubmit , handleChange , values , errors  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-center flex-col place-items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mt-[20px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                        value: values.email,
                                                        onChange: handleChange("email"),
                                                        component: "text",
                                                        placeHolder: "Email address",
                                                        classes: "h-[40px] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                        fitWidth: true,
                                                        required: true,
                                                        error: errors.email,
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                            className: "text-green-700"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mt-[20px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customInput__WEBPACK_IMPORTED_MODULE_16__/* .CustomInput */ .t, {
                                                        value: values.password,
                                                        onChange: handleChange("password"),
                                                        component: "text",
                                                        type: visible ? "text" : "password",
                                                        placeHolder: "Password",
                                                        classes: "h-[40px] w-[320px] bg-gray-100 rounded-md no-underline px-4 shadow-md",
                                                        fitWidth: true,
                                                        required: true,
                                                        error: errors.password,
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                                            onClick: ()=>setVisible(!visible),
                                                            children: visible ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_7___default()), {})
                                                        }),
                                                        endAdornment: true
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex place-items-center mt-4 gap-2 text-[14px]",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            children: [
                                                                "Dont have an Account?",
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>setIsLogin(false),
                                                            className: "text-green-700",
                                                            children: "Sign Up"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex place-items-center mt-2 gap-2 text-[14px]",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "Forgot your password? click"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_18___default()), {
                                                            href: "/reset",
                                                            className: "text-green-700",
                                                            children: "here"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mt-[30px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                        onClick: ()=>handleSubmit(),
                                                        className: "bg-green-700 h-[40px] md:w-[320px] w-[320px] text-white",
                                                        children: "Sign In"
                                                    })
                                                })
                                            ]
                                        })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3514:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_application__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8931);
/* harmony import */ var _components_applicationStages_signup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5069);
/* harmony import */ var _components_navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8374);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3199);
/* harmony import */ var _components_notifier__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3993);
/* harmony import */ var _components_applicationStages_jobFilters__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4002);
/* harmony import */ var _components_applicationStages_jobList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6497);
/* harmony import */ var _mui_icons_material_ArrowBack__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3622);
/* harmony import */ var _mui_icons_material_ArrowBack__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ArrowBack__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _helpers_connection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1423);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_application__WEBPACK_IMPORTED_MODULE_3__, _components_applicationStages_signup__WEBPACK_IMPORTED_MODULE_4__, _helpers_connection__WEBPACK_IMPORTED_MODULE_11__]);
([_components_application__WEBPACK_IMPORTED_MODULE_3__, _components_applicationStages_signup__WEBPACK_IMPORTED_MODULE_4__, _helpers_connection__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Listings = ({ data  })=>{
    const [roles, setRoles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [searchVal, setSearchVal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [activeRole, setActiveRole] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [step, setStep] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [unit, setUnit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [isMobile, setIsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [applying, setApplying] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        value: false
    });
    const [nav, setNav] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        open: false
    });
    const [filter, setFilter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [filterType, setFilterType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [fields, setFields] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        location: "",
        skill: "",
        degree: ""
    });
    const [jobType, setJobType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [eduType, setEduType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [set, setSet] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showFilter, setShowFilter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [roleCount, setRoleCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [checkFields, setCheckFields] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        bachelors: false,
        masters: false,
        phd: false,
        fullTime: false,
        partTime: false,
        internship: false,
        contract: false
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (window.innerWidth <= 400) {
            setIsMobile(true);
            setShowFilter(false);
        }
    }, []);
    const handleChange = (e, type)=>{
        let update = {
            ...fields
        };
        update[type] = e.target.value;
        setFields(update);
        if (e.target.value != null) {
            setFilter(e.target.value);
            setFilterType(type);
            getAllRoles(0, e.target.value, type);
        }
    };
    const handleJobTypeChange = (e)=>{
        console.log(e.target.value);
        setJobType(e.target.value);
        getAllRoles(0, e.target.value, "JobType");
    };
    const handleEduTypeChange = (e)=>{
        console.log(e.target.value);
        setEduType(e.target.value);
        getAllRoles(0, e.target.value, "Qualification");
    };
    const handleCheckChange = (filter, filterType)=>{
        filter = filter.split(" ").join("");
        let update = {
            ...checkFields
        };
        if (!Object.values(checkFields).includes(true)) {
            update[filter] = !checkFields[filter];
            setCheckFields(update);
            if (update[filter] == true) {
                setSearchVal("");
                setFilter(filter);
                setFilterType(filterType);
                getAllRoles(0, filter, filterType);
            }
        }
    };
    //* global context containing login state
    const { loggedIn , setLoggedIn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context__WEBPACK_IMPORTED_MODULE_6__/* .MainContext */ .T);
    const changeFilter = (value, type)=>{
        setFilter(value);
        setFilterType(type);
    };
    const refreshJobsList = ()=>{
        setFilter("");
        setFilterType("");
        setSearchVal("");
        getAllRoles(0);
        window.scrollTo(0, 0);
    };
    //* gets all active job roles
    const getAllRoles = async (pageVal, filterVal, filterTypeVal)=>{
        let body = {
            value: searchVal,
            page: pageVal,
            filter: filterVal ?? "",
            filterType: filterTypeVal ?? ""
        };
        (0,_helpers_connection__WEBPACK_IMPORTED_MODULE_11__/* .postAsync */ .Am)("http://10.0.0.153:8443/roles/Role/all", body).then((res)=>{
            let data = res.data;
            setRoles(data);
            setActiveRole(data[0]);
            setRoleCount(res.data?.count);
            setSet(true);
        }).catch((err)=>{
        // console.log(err.message)
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getAllRoles(0, "", "");
    }, [
        searchVal
    ]);
    //* search for a job role
    const searchRole = (e)=>{
        setSearchVal(e.target.value);
    };
    //* deprecated
    const handleUnitChange = (event)=>{
        if (event.target.value == "All") {
            setUnit(null);
            getAllRoles(0);
        } else {
            setUnit(event.target.value);
        }
    };
    //* deprecated
    const units = [
        "Finance",
        "Networking",
        "Audit",
        "Legal",
        "Maintainance",
        "It",
        "All"
    ];
    //* selects a job role
    const handleRoleSelect = (role)=>{
        setActiveRole(role);
        setStep(1);
    };
    //* exits the job role application view
    const handleGoBack = ()=>{
        setStep(0);
    };
    //* toggles the job role application
    const handleApply = (data)=>{
        var user = sessionStorage.getItem("cred");
        if (user) {
            setActiveRole(data);
            setStep(2);
        } else {
            setApplying({
                value: true,
                source: "main"
            });
        }
    };
    //* deprecated will remove
    const login = ()=>{
        var user = sessionStorage.getItem("cred");
        if (!user) {
            setApplying({
                value: true,
                source: "nav"
            });
        }
    };
    //* deprecated will remove
    const logout = ()=>{
        sessionStorage.clear();
        setLoggedIn(false);
        setStep(1);
        clearStatus();
    // setStatus({
    //   open: true,
    //   topic: "Successful",
    //   content: "Logged Out Successfully"
    // })
    };
    //* displays the logout confirmation notifier
    const showLogout = ()=>{
        setStatus({
            open: true,
            topic: "Confirmation",
            content: "Are you sure you want to sign out",
            hasNext: true
        });
    };
    //* toggles application from the navbar
    const handleNav = (item)=>{
        setNav(item);
        setApplying({
            value: true
        });
    };
    //* clears the notifier state
    const clearStatus = ()=>setStatus({
            open: false
        });
    //* parses and maps through the job descriptions
    const parseDesc = (desc)=>{
        return JSON.parse(desc).map((item, idx)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row gap-4 mt-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: item?.["RowNum~~Blnk"]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "capitalize",
                                children: item?.["Job responsibility~~Sentc"].toLowerCase()
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
                ]
            }, idx));
    };
    // const container = window !== undefined ? () => window().document.body : undefined;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-slate-100",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                className: "flex justify-center",
                open: status?.open ? true : false,
                onClose: clearStatus,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_notifier__WEBPACK_IMPORTED_MODULE_7__/* .Notifier */ .d, {
                    hasNext: status.hasNext,
                    topic: status?.topic ?? "",
                    content: status?.content ?? "",
                    close: clearStatus
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                onClose: ()=>setApplying({
                        value: false
                    }),
                open: applying.value,
                className: "flex justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_applicationStages_signup__WEBPACK_IMPORTED_MODULE_4__/* .Signup */ .A, {
                    login: true,
                    exit: ()=>setApplying({
                            value: false
                        }),
                    next: ()=>applying.source != "main" ? setStep(1) : setStep(2),
                    nextPage: nav == "status" ? "applicant" : ""
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navbar__WEBPACK_IMPORTED_MODULE_5__/* .Navbar */ .w, {
                handleNav: handleNav,
                next: ()=>setStep(1)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-[60px] p-2",
                children: [
                    !showFilter && step == 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row justify-between shadow-md bg-white rounded-md p-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-xl font-semibold",
                                children: "All Jobs"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                onClick: ()=>setShowFilter(true),
                                className: "text-[12px] text-green-700",
                                children: "Show Filters"
                            })
                        ]
                    }),
                    step == 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-green-100 font-semibold text-xl w-[100%] md:h-[60px] h-[40px] justify-between flex flex-row md:p-4 p-2 fixed overflow-clip z-30",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: activeRole?.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                                onClick: ()=>setStep(1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ArrowBack__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    className: "text-green-700"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: step == 1 ? "md:grid md:grid-cols-7 md:gap-4 sm:flex sm:flex-col" : "md:grid md:grid-cols-7 sm:flex sm:flex-col md:gap-4 md:mt-[60px] mt-[40px] z-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: step == 1 ? "border-solid border-r-2 md:h-[100vh] bg-white md:col-span-2 self-start md:sticky top-[70px] md:grid" : "border-solid border-r-2 md:grid self-start md:sticky top-[70px] md:col-span-2",
                        children: step == 1 && showFilter ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_applicationStages_jobFilters__WEBPACK_IMPORTED_MODULE_8__/* .JobFilters */ .k, {
                            fields: fields,
                            change: handleChange,
                            searchVal: searchVal,
                            searchRole: searchRole,
                            checkFields: checkFields,
                            jobTypeChange: handleJobTypeChange,
                            jobType: jobType,
                            eduType: eduType,
                            eduTypeChange: handleEduTypeChange,
                            mobile: isMobile,
                            hideFilter: ()=>setShowFilter(false)
                        }) : step == 2 && !isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "sticky",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_applicationStages_jobList__WEBPACK_IMPORTED_MODULE_9__/* .JobList */ .n, {
                                roles: roles,
                                setRole: setRoles,
                                apply: handleApply,
                                getRoles: getAllRoles,
                                currentStep: step,
                                refresh: refreshJobsList,
                                count: roleCount
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[100%] col-span-5 mt-4 md:mt-0",
                        children: step == 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_applicationStages_jobList__WEBPACK_IMPORTED_MODULE_9__/* .JobList */ .n, {
                            roles: roles,
                            setRole: setRoles,
                            apply: handleApply,
                            getRoles: getAllRoles,
                            currentStep: step,
                            refresh: refreshJobsList,
                            count: roleCount
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "sticky self-start top-[70px]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_application__WEBPACK_IMPORTED_MODULE_3__/* .Application */ .M, {
                                ...activeRole
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Drawer, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Listings);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4463:
/***/ (() => {



/***/ })

};
;