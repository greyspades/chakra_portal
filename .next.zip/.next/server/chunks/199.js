"use strict";
exports.id = 199;
exports.ids = [199];
exports.modules = {

/***/ 3199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ MainContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const MainContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
const Context = (props)=>{
    const [candidate, setCandidate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [role, setRole] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [editableRole, setEditableRole] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [activePage, setActivePage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [candidates, setCandidates] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [loggedIn, setLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [admin, setAdmin] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MainContext.Provider, {
        value: {
            candidate: candidate,
            setCandidate: setCandidate,
            role: role,
            setRole: setRole,
            editableRole: editableRole,
            setEditableRole,
            activePage,
            setActivePage,
            candidates,
            setCandidates,
            loggedIn,
            setLoggedIn,
            admin,
            setAdmin
        },
        children: props.children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Context); // export async function getServerSide


/***/ })

};
;