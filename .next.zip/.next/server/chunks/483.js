"use strict";
exports.id = 483;
exports.ids = [483];
exports.modules = {

/***/ 483:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$F": () => (/* binding */ AcceptanceInfoValidation),
/* harmony export */   "CV": () => (/* binding */ PasswordReset),
/* harmony export */   "Gx": () => (/* binding */ SignInValidation),
/* harmony export */   "NT": () => (/* binding */ ApplicationValidation),
/* harmony export */   "RS": () => (/* binding */ AdminForm),
/* harmony export */   "Wj": () => (/* binding */ InterviewForm),
/* harmony export */   "u6": () => (/* binding */ CreateJobValidation),
/* harmony export */   "uE": () => (/* binding */ CandidateValidation)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);

//* calculates the candidates age and validates the birthday
const calculateAge = (birthday)=>{
    var ageDifMs = Date.now() - birthday;
    var ageDate = new Date(ageDifMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
};
//* validation schema for cover letter
const ApplicationValidation = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    coverLetter: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("this field is fequired")
});
//* validation information for a candidate
const CandidateValidation = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    email: yup__WEBPACK_IMPORTED_MODULE_0__.string().email("The email is invalid").required("This field is required"),
    password: yup__WEBPACK_IMPORTED_MODULE_0__.string().min(8, "The password is too short").max(50, "The password is too long").matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/, "must contain at least one uppercase, one number, and one special character").required("This field is required"),
    firstName: yup__WEBPACK_IMPORTED_MODULE_0__.string().max(30, "Maximum of 30 characters").required("this field is required"),
    lastName: yup__WEBPACK_IMPORTED_MODULE_0__.string().max(30, "Maximum of 30 characters").required("this field is required"),
    otherName: yup__WEBPACK_IMPORTED_MODULE_0__.string().max(30, "Maximum of 30 characters").required("this field is required"),
    dob: yup__WEBPACK_IMPORTED_MODULE_0__.date().required("this field is required").test("birthday", "Must be upto 18 years of age", function(val) {
        return calculateAge(new Date(val)) > 18;
    }),
    validPassword: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("this field is required").oneOf([
        yup__WEBPACK_IMPORTED_MODULE_0__.ref("password")
    ], "Your passwords do not match."),
    address: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("this field is fequired")
});
//* validation for the sign in form
const SignInValidation = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    email: yup__WEBPACK_IMPORTED_MODULE_0__.string().email("The email is invalid").required("This field is required"),
    password: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required")
});
//* validation for creating a new job role
const CreateJobValidation = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required"),
    course: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required"),
    // location: Yup.string()
    // .required('This field is required'),
    // qualification: Yup.string()
    // .required('This field is required'),
    deadline: yup__WEBPACK_IMPORTED_MODULE_0__.date().required("this field is required").min(new Date(), "Please select a future date")
});
const AcceptanceInfoValidation = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    state: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required"),
    rank: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required"),
    location: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required"),
    reportTo: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required"),
    salary: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("This field is required"),
    salWords: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required"),
    startDate: yup__WEBPACK_IMPORTED_MODULE_0__.date().required("this field is required").min(new Date(), "Please select a future date")
});
const PasswordReset = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    password: yup__WEBPACK_IMPORTED_MODULE_0__.string().min(8, "The password is too short").max(50, "The password is too long").required("This field is required"),
    confirmPassword: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("this field is required").oneOf([
        yup__WEBPACK_IMPORTED_MODULE_0__.ref("password")
    ], "Your passwords do not match.")
});
//* validation for interview scheduling
const InterviewForm = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    date: yup__WEBPACK_IMPORTED_MODULE_0__.date().required("this field is required").min(new Date(), "Please select a future date"),
    time: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("this field is required"),
    topic: yup__WEBPACK_IMPORTED_MODULE_0__.string().notRequired()
});
//* validation for admin login
const AdminForm = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    userId: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("this field is required"),
    password: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("This field is required")
});


/***/ })

};
;