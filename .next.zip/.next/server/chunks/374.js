"use strict";
exports.id = 374;
exports.ids = [374];
exports.modules = {

/***/ 8374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3882);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1431);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3199);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _notifier__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3993);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);










const Navbar = ({ handleNav , logOut , next  })=>{
    const { loggedIn , setLoggedIn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context__WEBPACK_IMPORTED_MODULE_6__/* .MainContext */ .T);
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        open: false
    });
    //* nextjs navigation hook
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    //* gets the candidate information from session storage
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let cred = sessionStorage.getItem("cred");
        if (cred) {
            setLoggedIn(true);
        }
    }, []);
    //* renders the names and paths of all pages
    const renderPageName = ()=>{
        switch(router.pathname){
            case "/":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "font-semibold md:text-2xl",
                    children: "Job Listings"
                });
            case "/statusform":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "font-semibold md:text-2xl",
                    children: "Check Status"
                });
            case "/applicant":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "font-semibold md:text-2xl",
                    children: "Application Status"
                });
            case "/admin":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "font-semibold md:text-2xl",
                    children: "Admin"
                });
            case "/signin":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "font-semibold md:text-2xl",
                    children: "Sign In"
                });
            case "/confirmation":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "font-semibold md:text-2xl",
                    children: "Confirmation"
                });
            default:
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {});
        }
    };
    //* logs the user out
    const logout = ()=>{
        sessionStorage.clear();
        setLoggedIn(false);
        clearStatus();
        next?.();
        router.push("/");
    };
    //* displays the logout notification
    const showLogout = ()=>{
        setStatus({
            open: true,
            topic: "Confirmation",
            content: "Are you sure you want to sign out?",
            hasNext: true
        });
    };
    //* paths without a highlight on navbar
    const pathsWithoutStatus = [
        "/admin",
        "/signin",
        "/reset"
    ];
    //* paths with a highlight
    const statusPages = [
        "/statusform",
        "/applicant",
        "/reset"
    ];
    //* clears the notifier state
    const clearStatus = ()=>setStatus({
            open: false
        });
    //* checks session status and navigates to the application or status check screens
    const handleStatusNav = ()=>{
        if (loggedIn) {
            router.push("/applicant");
        } else {
            handleNav?.("status");
        }
    };
    const protectedRoutes = [
        "admin",
        "signup",
        "status"
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                className: "flex justify-center",
                open: status?.open ? true : false,
                onClose: clearStatus,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_notifier__WEBPACK_IMPORTED_MODULE_8__/* .Notifier */ .d, {
                        hasNext: status.hasNext,
                        topic: status?.topic ?? "",
                        content: status?.content ?? "",
                        close: clearStatus,
                        other: ()=>logout()
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_4___default()), {
                sx: {
                    flexGrow: 1
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_3___default()), {
                    position: "fixed",
                    className: "bg-white text-black max-h-[60px]",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_5___default()), {
                        className: "flex flex-row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: "grid col-span-1",
                                src: "/logo.png",
                                width: 100,
                                height: 100,
                                alt: "/"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row justify-end ml-auto md:gap-8 gap-3",
                                children: [
                                    router.pathname != "admin" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        href: "/",
                                        className: router.pathname == "/" ? "flex place-items-center text-black bg-green-300 h-[20px] w-[70px] md:text-[14px] text-[12px] md:h-[30px] md:w-[100px] text-center rounded-md p-1" : "flex place-items-center text-black h-[20px] w-[70px] md:text-[14px] text-[12px] md:h-[30px] md:w-[100px]",
                                        children: "Job listings"
                                    }),
                                    !pathsWithoutStatus.includes(router.pathname) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        onClick: handleStatusNav,
                                        href: "#",
                                        className: statusPages.includes(router.pathname) ? "flex place-items-center text-black bg-green-300 h-[20px] w-[80px] md:text-[14px] text-[12px] md:h-[30px] md:w-[100px] text-center rounded-md p-1" : "flex place-items-center text-black h-[20px] w-[70px] md:text-[14px] text-[12px] md:h-[30px] md:w-[100px]",
                                        children: "Check Status"
                                    }),
                                    router.pathname == "/admin" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: logOut,
                                        children: "Sign Out"
                                    }),
                                    ![
                                        "/admin",
                                        "/signin",
                                        "/reset"
                                    ].includes(router.pathname) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-[12px]",
                                        children: loggedIn ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: showLogout,
                                            className: "text-black h-[20px] w-[70px] md:text-[14px] text-[12px] md:h-[30px] md:w-[100px]",
                                            children: "Sign Out"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>handleNav?.("sign in"),
                                            className: "text-black h-[20px] w-[70px] md:text-[14px] text-[12px] md:h-[30px] md:w-[100px]",
                                            children: "Sign In"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};


/***/ }),

/***/ 3993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ Notifier)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_ReportProblem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4527);
/* harmony import */ var _mui_icons_material_ReportProblem__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ReportProblem__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_DoneAll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4914);
/* harmony import */ var _mui_icons_material_DoneAll__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DoneAll__WEBPACK_IMPORTED_MODULE_4__);





const Notifier = ({ topic , content , close , other , hasNext  })=>{
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Paper, {
            className: "flex flex-col w-[300px] mt-[70px] justify-items-center md:h-auto bg-slate-100 overflow-y-scroll p-4 pb-0",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-row gap-3",
                    children: [
                        topic.toLowerCase() != "successful" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ReportProblem__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: "text-green-700 w-[40px] h-[40px] mt-[-5px]"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_DoneAll__WEBPACK_IMPORTED_MODULE_4___default()), {
                            className: "text-green-700 w-[40px] h-[40px] mt-[-5px]"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "capitalize text-xl font-semibold",
                            children: topic
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-white p-3 rounded-md mt-[20px] h-auto flex justify-center text-center",
                    children: content
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex m-[10px] justify-end gap-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            onClick: ()=>close(),
                            className: "bg-green-700 h-[30px] text-white capitalize",
                            children: "Close"
                        }),
                        other && hasNext && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            onClick: ()=>other?.(),
                            className: "bg-green-700 h-[30px] text-white capitalize",
                            children: "Proceed"
                        })
                    ]
                })
            ]
        })
    });
};


/***/ })

};
;