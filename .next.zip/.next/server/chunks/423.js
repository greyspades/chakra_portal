"use strict";
exports.id = 423;
exports.ids = [423];
exports.modules = {

/***/ 1423:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Am": () => (/* binding */ postAsync),
/* harmony export */   "L5": () => (/* binding */ getContent)
/* harmony export */ });
/* unused harmony exports postContent, postCustom */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5666);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _formating__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(232);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




var key = crypto_js__WEBPACK_IMPORTED_MODULE_2___default().enc.Utf8.parse("yy7a1^.^^j_ii^c2^5^ho_@.9^d7bi^.");
var iv = crypto_js__WEBPACK_IMPORTED_MODULE_2___default().enc.Utf8.parse("h!!_2bz^(@?yyq!.");
const getContent = async (url)=>{
    let reqHeader = crypto_js__WEBPACK_IMPORTED_MODULE_2___default().AES.encrypt("68a4b2bfc07444b7822c3e8a14cbac6d732311b8c9344096a32ea51c568193c7", key, {
        iv: iv
    }).toString();
    const options = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            head: reqHeader,
            // body: reqBody,
            url: url,
            method: "GET"
        })
    };
    var response = await fetch("/api/connect", options);
    var jsonRes = await response.json();
    if (jsonRes) {
        let bytes = crypto_js__WEBPACK_IMPORTED_MODULE_2___default().AES.decrypt(jsonRes.data, key, {
            iv: iv
        });
        let resData = JSON.parse(bytes.toString((crypto_js__WEBPACK_IMPORTED_MODULE_2___default().enc.Utf8)));
        jsonRes.data = resData;
    }
    return jsonRes;
};
const postContent = async (url, body)=>{
    let encrypted = CryptoJs.AES.encrypt(JSON.stringify(body), key, {
        iv: iv
    }).toString();
    let reqHeader = CryptoJs.AES.encrypt("68a4b2bfc07444b7822c3e8a14cbac6d732311b8c9344096a32ea51c568193c7", key, {
        iv: iv
    }).toString();
    const options = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            head: reqHeader,
            body: body,
            url: url,
            method: "POST"
        })
    };
    var response = await fetch("/api/create", options);
    var jsonRes = await response.json();
    console.log(jsonRes);
    if (jsonRes.data) {
        return jsonRes;
    }
};
const postAsync = async (url, body)=>{
    if (body && url) {
        let reqBody = crypto_js__WEBPACK_IMPORTED_MODULE_2___default().AES.encrypt(JSON.stringify(body), key, {
            iv: iv
        }).toString();
        let reqHeader = crypto_js__WEBPACK_IMPORTED_MODULE_2___default().AES.encrypt("68a4b2bfc07444b7822c3e8a14cbac6d732311b8c9344096a32ea51c568193c7", key, {
            iv: iv
        }).toString();
        const options = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                head: reqHeader,
                body: reqBody,
                url: url,
                method: "POST"
            })
        };
        var response = await fetch("/api/connect", options);
        var jsonRes = await response.json();
        // console.log(jsonRes)
        if (jsonRes?.data) {
            let bytes = crypto_js__WEBPACK_IMPORTED_MODULE_2___default().AES.decrypt(jsonRes.data, key, {
                iv: iv
            });
            let resData = JSON.parse(bytes.toString((crypto_js__WEBPACK_IMPORTED_MODULE_2___default().enc.Utf8)));
            // console.log(resData)
            // console.log(url)
            if (Array.isArray(resData)) {
                jsonRes.data = (0,_formating__WEBPACK_IMPORTED_MODULE_3__/* .lowerKeyArray */ .j)(resData);
            } else if (typeof resData === "object" && resData !== null) {
                jsonRes.data = (0,_formating__WEBPACK_IMPORTED_MODULE_3__/* .lowerKey */ .w)(resData);
            } else {
                jsonRes.data = resData;
            }
            return jsonRes;
        } else {
            return jsonRes;
        }
    }
};
const postCustom = async (url, body)=>{
    let encrypted = CryptoJs.AES.encrypt(JSON.stringify(body), key, {
        iv: iv
    }).toString();
    console.log(encrypted);
    let response = await axios.post(url, encrypted, {
        headers: {
            Auth: CryptoJs.AES.encrypt("68a4b2bfc07444b7822c3e8a14cbac6d732311b8c9344096a32ea51c568193c7", key, {
                iv: iv
            }).toString()
        }
    }).then((res)=>res.data);
    if (response.data) {
        let bytes = CryptoJs.AES.decrypt(response.data, key, {
            iv: iv
        });
        let resData = JSON.parse(bytes.toString(CryptoJs.enc.Utf8));
        if (Array.isArray(resData)) {
            response.data = lowerKeyArray(resData);
        } else if (typeof resData === "object" && resData !== null) {
            response.data = lowerKey(resData);
        } else {
            response.data = resData;
        }
        return response;
    } else {
        return response;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 232:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ lowerKeyArray),
/* harmony export */   "w": () => (/* binding */ lowerKey)
/* harmony export */ });
const lowerKey = (obj)=>{
    const result = {};
    for(const key in obj){
        if (Object.hasOwnProperty.call(obj, key)) {
            result[key.toLowerCase()] = obj[key];
        }
    }
    return result;
};
const lowerKeyArray = (arr)=>{
    return arr.map((obj)=>{
        const newObj = {};
        for(const key in obj){
            if (Object.hasOwnProperty.call(obj, key)) {
                newObj[key.toLowerCase()] = obj[key];
            }
        }
        return newObj;
    });
};


/***/ })

};
;