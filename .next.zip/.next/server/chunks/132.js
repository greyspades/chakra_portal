"use strict";
exports.id = 132;
exports.ids = [132];
exports.modules = {

/***/ 2132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3199);


const AppMonitor = ({ children , time  })=>{
    const { setCandidates , loggedIn , setLoggedIn  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context__WEBPACK_IMPORTED_MODULE_1__/* .MainContext */ .T);
    const events = [
        "load",
        "mousemove",
        "mousedown",
        "click",
        "scroll",
        "keypress"
    ];
    let timer;
    // this function sets the timer that logs out the user after 10 secs
    const handleLogoutTimer = ()=>{
        timer = setTimeout(()=>{
            // clears any pending timer.
            resetTimer();
            // Listener clean up. Removes the existing event listener from the window
            Object.values(events).forEach((item)=>{
                window.removeEventListener(item, resetTimer);
            });
            // logs out user
            logoutAction();
        }, time); // 10000ms = 10secs. You can change the time.
    };
    // this resets the timer if it exists.
    const resetTimer = ()=>{
        if (timer) clearTimeout(timer);
    };
    const logoutAction = ()=>{
        sessionStorage.clear();
        setLoggedIn(false);
        // window.location.pathname = "/"
        window.location.reload();
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        Object.values(events).forEach((item)=>{
            window.addEventListener(item, ()=>{
                resetTimer();
                handleLogoutTimer();
            });
        });
    }, []);
    return children;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppMonitor);


/***/ })

};
;